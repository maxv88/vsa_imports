.. _tools:

.. include:: global.txt

Format Conversion Tools
=======================

Additional utility functions for converting suds xml
object into other formats.

Basic Suds Object to Dictionary
-------------------------------

.. autofunction:: fedex.tools.conversion.basic_sobject_to_dict

Advanced Suds Object to Dictionary
----------------------------------

.. autofunction:: fedex.tools.conversion.sobject_to_dict

Suds Object to JSON
-------------------

.. autofunction:: fedex.tools.conversion.sobject_to_json
