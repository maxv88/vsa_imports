epydoc-2.6 -v --config epydoc.config --check
