.. _suds_plugin:

.. include:: global.txt

General Suds Plugin
===================

python-fedex uses the following suds plugin for suds xml requests.


.. autoclass:: fedex.base_service.GeneralSudsPlugin
