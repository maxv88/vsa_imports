.. _installation:

.. include:: global.txt

Installation
============

python-fedex is compatible with Python 2.7+. The only other
requirement is suds_jurko_ although the module is also compatible with the
original suds module.

For those on Linux/Unix Mac OS, the easiest route will be :command:`pip` or
:command:`easy_install`::

    pip install fedex
