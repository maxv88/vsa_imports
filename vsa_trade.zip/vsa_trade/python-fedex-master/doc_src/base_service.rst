.. _base_service:

.. include:: global.txt

Base Service Class
==================

.. autoclass:: fedex.base_service.FedexBaseService

