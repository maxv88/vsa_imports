.. python-fedex documentation master file, created by
   sphinx-quickstart on Sat Jan 30 21:51:05 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: global.txt

Python-Fedex: a suds fedex api wrapper
======================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   quick_start
   services
   tools
   config_object
   base_service
   exceptions
   suds_plugin


.. toctree::
   :maxdepth: 1

   release_notes


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

