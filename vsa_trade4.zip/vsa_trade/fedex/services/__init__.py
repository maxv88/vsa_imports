"""
This module contains the wrappers around Fedex Web Service requests which you
will want to instantiate and use with a L{FedexConfig} object supplying
your static details. Each module here corresponds to a Fedex WSDL.
"""
