.. _config_object:

.. include:: global.txt

Config Object
=============

A standardized configuration container object used
by python-fedex.

.. autoclass:: fedex.config.FedexConfig


